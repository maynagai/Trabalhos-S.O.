#include<stdio.h>
#include<stdlib.h>

#define MAX 10

typedef struct
{
    int processo;
} REGISTRO;

typedef struct
{
    REGISTRO A[MAX];
    int inicio;
    int nroElem;
} FILA;

void inicializar(FILA* f)
{
    f->inicio=0;
    f->nroElem=0;
}

int inserirFila(FILA *f,REGISTRO reg)
{

    int i=0;
    int posicao = (f->inicio + f->nroElem) % MAX;
    if(f->nroElem >=MAX)
    {
        printf("ERRO \n");
        return -1;
    }
    else
    {
        f->A[posicao] = reg;
        f->nroElem++;
        return 0;
    }
}

void exibirFila(FILA* f)
{
    int i= f->inicio;
    int aux;
    for(aux=0; aux< f->nroElem; aux++)
    {
        printf("%d",f->A[i].processo);
        i=(i+1)%MAX;
    }
    printf("\n");
}

int inserirElemento(int tam, int* v, int inicio, int fim)
{
    int valor,i;
    for(i=fim; i<10; i++)
    {
        valor=rand()%10;
        v[i]=valor;
        fim++;
    }
    return fim;

}
int retirarElemento(int tam, int *v, int inicio, int fim)
{
    int i=0;
    for(i=inicio; i<10; i++)
    {
        inicio++;
        tam++;
    }
    return tam;
    return inicio;
}

int exibirVetor(int tam, int* v, int fim){
int i;
for(i=0;i<1000;i++){
printf("vetor[%d]=%d\n", i, v[i]);
}
}

int main()
{
    int i=0,count1=0,count0=0,count=0,aux=0,tam=1000,carga=0;
    FILA processo;
    REGISTRO reg;
    int vetor[tam], inicioVetor=0, fimVetor=0;


        inicializar(&processo);
        for(i=0; i<10; i++)
        {
            reg.processo=rand()%2;

            if(count1==5 || count0==5){

                count= count0+count1;
                if(count1==5){
                    for(i=count;i<10;i++){
                        reg.processo=0;
                        inserirFila(&processo,reg);
                        //retirarElemento(tam,vetor,inicioVetor,fimVetor);


                    }
                }
                else if(count0==5){
                    for(i=count;i<10;i++){
                        reg.processo=1;
                        inserirFila(&processo,reg);
                        //inserirElemento(tam,vetor,inicioVetor,fimVetor);

                    }
                }

            }

            else {
            inserirFila(&processo,reg);
            }

            if(reg.processo==1){
             count1++;
             inserirElemento(tam,vetor,inicioVetor,fimVetor);

             }
            else if(reg.processo==0){
            count0++;
            retirarElemento(tam,vetor,inicioVetor,fimVetor);

            }

        }

    //exibirVetor(tam,vetor,fimVetor);
    exibirFila(&processo);
    return 0;
}

